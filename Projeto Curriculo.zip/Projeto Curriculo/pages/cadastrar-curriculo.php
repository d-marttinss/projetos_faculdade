<h1>Cadastrar Curriculo</h1>
<form action="?page=salvar-atendente" method="POST">
	<input type="hidden" name="acao" value="cadastrar">
	<div class="mb-3">
		<label>Nome Completo</label>
		<input type="text" name="nome_pessoa" class="form-control">
	</div>
	<div class="mb-3">
		<label>Telefone</label>
		<input type="text" name="telefone_pessoa" class="form-control">
	</div>
	<div class="mb-3">
		<label>E-mail</label>
		<input type="text" name="email_pessoa" class="form-control">
	</div>
	<div class="mb-3">
		<label>Idade</label>
		<input type="number" name="idade_pessoa" class="form-control">
	</div>
	<div class="mb-3">
		<label>Gênero</label>
		<input type="text" name="genero_pessoa" class="form-control">
	</div>
	<div class="mb-3">
		<label>Estado Civil</label>
		<input type="text" name="estado_civil_pessoa" class="form-control">
	</div>
	<div class="mb-3">
		<label>Endereço</label>
		<input type="text" name="endereco_pessoa" class="form-control">
	</div>
	<div><h3>Formação Acadêmica</h3></div>
	<div class="mb-3">
		<label>Curso</label>
		<input type="text" name="curso_formacao" class="form-control">
	</div>
	<div class="mb-3">
		<label>Ano de formamção</label>
		<input type="number" name="ano_formacao" class="form-control">
	</div>
	<div class="mb-3">
		<label>Instituição de formação</label>
		<input type="text" name="instituicao_formacao" class="form-control">
	</div>
	<div><h3>Ultima experiência</h3></div>
	<div class="mb-3">
		<label>Empresa</label>
		<input type="text" name="empresa_experiencia" class="form-control">
	</div>
	<div class="mb-3">
		<label>Cargo</label>
		<input type="text" name="cargo_experiencia" class="form-control">
	</div>
	<div class="mb-3">
		<label>Anos de experiência</label>
		<input type="number" name="anos_experiencia" class="form-control">
	</div>
	<br>
	<div class="mb-3">
		<button type="submit" class="btn btn-primary">Enviar</button>
	</div>
</form>