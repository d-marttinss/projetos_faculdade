<?php
	switch($_REQUEST['acao']){
		case "cadastrar":
			$nome = $_POST["nome_pessoa"];
			$telefone = $_POST["telefone_pessoa"];
			$email = $_POST["email_pessoa"];
			$idade = $_POST["idade_pessoa"];
			$genero = $_POST["genero_pessoa"];
			$estado_civil = $_POST["estado_civil_pessoa"];
			$endereco = $_POST["endereco_pessoa"];
			$curso_formacao = $_POST["curso_formacao"];
			$ano_formacao = $_POST["ano_formacao"];
			$instituicao_formacao = $_POST["instituicao_formacao"];
			$empresa = $_POST["empresa_experiencia"];
			$cargo = $_POST["cargo_experiencia"];
			$anos_experiencia = $_POST["anos_experiencia"];
			

			$sql = "INSERT INTO pessoa 
				(nome_pessoa, 
				telefone_pessoa, 
				email_pessoa, 
				idade_pessoa, 
				genero_pessoa, 
				estado_civil_pessoa, 
				endereco_pessoa, 
				curso_formacao, 
				ano_formacao, 
				instituicao_formacao, 
				empresa_experiencia, 
				cargo_experiencia, 
				anos_experiencia) 
				VALUES 
					('{$nome}', 
					'{$telefone}', 
					'{$email}', 
					 {$idade}, 
					'{$genero}', 
					'{$estado_civil}', 
					'{$endereco}', 
					'{$curso_formacao}', 
					 {$ano_formacao}, 
					'{$instituicao_formacao}', 
					'{$empresa}', 
					'{$cargo}', 
					{$anos_experiencia})";

			$res = $conn->query($sql);

			if($res==true){
				print "<script>alert('Cadastrou com sucesso!');</script>";
				print "<script>location.href='?page=listar-atendente';</script>";
			}else{
				print "<script>alert('Não foi possível cadastrar');</script>";
				print "<script>location.href='?page=listar-atendente';</script>";
			}
		break;

		case "editar":
			$sql = "DELETE FROM pessoa WHERE `pessoa`.`id_pessoa` = 0";
			$res = $conn->query($sql);
			if($res==true){
				print "<script>location.href='?page=cadastrar-curriculo';</script>";
			}else{
				print "<script>location.href='?page=cadastrar-curriculo';</script>";
			}
		break;

		case "excluir":

		break;
	}


