<h1>Curriculo Vitae</h1>
<br>
<?php
	$sql = "SELECT * FROM pessoa";
	$res = $conn->query($sql);
	$qtd = $res->num_rows;

	if($qtd > 0){
		


		while($row = $res->fetch_object()){
			


			print "<div class='card'>";
				print "<div class='card-header'> Dados Pessoais</div>";
					print "<div class='card-body'>";
						print "<table class='table table-bordered table-striped table-hover'>";
							print "<tr>";
								print "<th>Nome Completo</th>";
								print "<th>Telefone</th>";
								print "<th>E-mail</th>";
								print "<th>Idade</th>";
								print "<th>Gênero</th>";
								print "<th>Estado Civil</th>";
								print "<th>Endereço</th>";
							print "</tr>";
							print "<tr>";
								print "<td>".$row->nome_pessoa."</td>";
								print "<td>".$row->telefone_pessoa."</td>";
								print "<td>".$row->email_pessoa."</td>";
								print "<td>".$row->idade_pessoa."</td>";
								print "<td>".$row->genero_pessoa."</td>";
								print "<td>".$row->estado_civil_pessoa."</td>";
								print "<td>".$row->endereco_pessoa."</td>";
							print "</tr>";
						print "</table>";
					print "</div>";
			print "</div>";
			print "<br>";
						

			print "<div class='card'>";
				print "<div class='card-header'> Formação</div>";
					print "<div class='card-body'>";
						print "<table class='table table-bordered table-striped table-hover'>";
							print "<tr>";
								print "<th>Curso</th>";
								print "<th>Instituição</th>";
								print "<th>Ano de Conclusão</th>";
							print "</tr>";
							print "<tr>";
								print "<td>".$row->curso_formacao."</td>";
								print "<td>".$row->instituicao_formacao."</td>";
								print "<td>".$row->ano_formacao."</td>";
							print "</tr>";
						print "</table>";
				print "</div>";
			print "</div>";
			print "<br>";
			

			print "<div class='card'>";
				print "<div class='card-header'> Experiência</div>";
					print "<div class='card-body'>";
						print "<table class='table table-bordered table-striped table-hover'>";
							print "<tr>";
								print "<th>Curso</th>";
								print "<th>Instituição</th>";
								print "<th>Ano de Conclusão</th>";
							print "</tr>";
							print "<tr>";
								print "<td>".$row->empresa_experiencia."</td>";
								print "<td>".$row->cargo_experiencia."</td>";
								print "<td>".$row->anos_experiencia."</td>";
							print "</tr>";
						print "</table>";
					print "</div>";
			print "</div>";
			print "<br>";
			
			print "<form action='?page=salvar-curriculo' method='POST'>";
				print "<input type='hidden' name='acao' value='editar'>";
				print "<div class='mb-3'>";
					print "<button type='submit' class='btn btn-primary'>Novo Curriculo</button>";
				print "</div>";
			print "</form>";
		

			
		}
	}else{
		print "<div class='alert alert-danger'><p>Não encontrou resultado</p></div>";
	}
?>