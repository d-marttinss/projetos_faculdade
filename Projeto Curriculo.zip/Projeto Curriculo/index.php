<!DOCTYPE html>
<html lang="pt-BR">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <title>Curriculo.ORG</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
      <div class="container-fluid">
        <a class="navbar-brand" href="index.php">Curriculo.ORG</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNavDropdown">
          <ul class="navbar-nav">
            <li class="nav-item">
              <a class="nav-link active" aria-current="page" href="index.php">Home</a>
            </li>
            
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Curriculo
              </a>
              <ul class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                <li><a class="dropdown-item" href="?page=cadastrar-curriculo">Cadastrar</a></li>
                <li><a class="dropdown-item" href="?page=mostrar-curriculo">Imprimir</a></li>
              </ul>
            </li>

          </ul>
        </div>
      </div>
    </nav>

    <div class="container">
      <div class="row">
        <div class="col mt-5">
          <?php
            include("config.php");

            switch (@$_REQUEST["page"]) {

              case 'cadastrar-curriculo':
                include("pages/cadastrar-curriculo.php");
                break;
              case 'mostrar-curriculo':
                include("pages/mostrar-curriculo.php");
                break;
              case 'salvar-curriculo':
                include("pages/salvar-curriculo.php");
                break;
              
              default:
                print "<h1>Seja bem vindo</h1>";
                print "<img src='https://portal.unit.br/wp-content/uploads/2021/04/imagem-curriculo.png' class='img-fluid' alt='Imagem padrão de currículo'>";
            }

          ?>
        </div>
      </div>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
  </body>
</html>