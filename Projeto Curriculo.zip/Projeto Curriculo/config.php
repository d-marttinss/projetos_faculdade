<?php
	define('HOST', 'localhost');
	define('USER', 'root');
	define('PASS', '');
	define('BASE', 'curriculo');

	$conn = new MySQLi(HOST,USER,PASS,BASE);